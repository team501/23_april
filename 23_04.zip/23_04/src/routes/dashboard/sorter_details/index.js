/**
 * Dasboard Routes
 */
import React, { Component } from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';


//Reloadable card
import {
	InductsForTheDayWidget,
	WaveStatusWidget,
	InductsForTheLastHourWidget,
	SortsForTheDayWidget,
	SortsForTheLastHourWidget,
	SortersWidget,
	WatchesWidget,
	RuntimeWidget,
	StopsWidget,
	TotalWidget,
	InductionStatusWidget,
	ChuteStatusWidget} from "Components/Widgets";

// intl messages
import IntlMessages from 'Util/IntlMessages';

// page title bar
import PageTitleBar from 'Components/PageTitleBar/PageTitleBar';

//Chute Status Overview
import ChuteStatusOverview from 'Components/Widgets/KPI/ChuteStatusOverview'; 

//json
import json from 'JsnCnfg/MngEqpmnt/UntSrtrMnDshbrd/goalDetails.json';

export default class SorterDetails extends Component {

	linkState = this.props.location.state === undefined ? '' : this.props.location.state.data; 

   	constructor(props) {
		super(props);
		this.state = { currentTime: {} };
	}

	//Starting cyclic-refresh.
	async componentDidMount() {		
		this.intervalID = setInterval( () => this.timeGenrator(), localStorage.getItem("refreshInterval") );
	}

	/*Refresh callback function,
	*responsible for generating time as props for child elements.*/
	async timeGenrator() {
		console.log(".....................................");
		this.setState({ currentTime: new Date().getTime() });
	}

	//Clearing previous interval on component unmount.
	componentWillUnmount() {
		clearInterval(this.intervalID);
	}

   render() {
		const { match } = this.props;
		// fetch Sorter ID from URL Params
		const { sorterID } = this.props.match.params;
		
		console.log("sorterID");
		console.log(sorterID);
		//Sorter Details From JSON
		const sorterDetails = json.container.component.goalDetails;
		
		//for individual goal values
		let inductGoalPerDay = "";
		let inductGoalPerHour = "";
		let sortsGoalPerDay = "";
		let sortsGoalPerHour = "";
		let name = "";
		
		console.log(sorterDetails);
		
		//Fetching individual goal value for respective sorter by filtering out other sorters 
		sorterDetails.filter(data => data.name == sorterID).map(element => {
																	inductGoalPerDay = element.inductGoalPerDay;
																	inductGoalPerHour = element.inductGoalPerHour;
																	sortsGoalPerDay = element.sortsGoalPerDay;
																	sortsGoalPerHour = element.sortsGoalPerHour;				
															});						
		
      return (
         <div>
			<PageTitleBar 
				title={sorterID} 
				match={match}
				url="/app/dashboard/manageEquipment" 
				urlState={sorterID}
			/>
            <div className="row row-no-margin">
            	<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 col-class-left">
					{/*Passing sorterid for sorter id, goal for individual Goal Values  and current time.*/}
					<InductsForTheDayWidget currentTime={this.state.currentTime} sorterid={sorterID} goal={inductGoalPerDay} />
					<InductsForTheLastHourWidget currentTime={this.state.currentTime} sorterid={sorterID} goal={inductGoalPerHour} />
					<SortsForTheDayWidget currentTime={this.state.currentTime} sorterid={sorterID} goal={sortsGoalPerDay} />
					<SortsForTheLastHourWidget currentTime={this.state.currentTime} sorterid={sorterID} goal={sortsGoalPerHour} />
            	</div>
            	<div className="col-sm-8 col-md-8 col-lg-8 col-xl-8 col-class-right">
	            	<div colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full">
	            		<RuntimeWidget currentTime={this.state.currentTime} sorterId={sorterID} />
						<TotalWidget currentTime={this.state.currentTime} sorterId={sorterID} />
	            		<StopsWidget currentTime={this.state.currentTime} sorterId={sorterID} />
	            		<div className="clearboth"></div>
	            	</div>
	            		
            		<InductionStatusWidget currentTime={this.state.currentTime} sorterId={sorterID} nextLink={sorterID} />
					<ChuteStatusOverview currentTime={this.state.currentTime} sorterId={sorterID} nextLink={sorterID} /> 
            	</div>
            </div>
            <div className="clearboth"></div>
         </div>
         
      )
   }
}


