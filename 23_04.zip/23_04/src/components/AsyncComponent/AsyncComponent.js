/**
 * AsyncComponent
 * Code Splitting Component / Server Side Rendering / Need to add any route we can create here related section then go to the route folder and call related export in route.
 */
import React from 'react';
import Loadable from 'react-loadable';

// rct page loader
import RctPageLoader from 'Components/RctPageLoader/RctPageLoader';

// ecommerce dashboard
const AsyncEcommerceDashboardComponent = Loadable({
	loader: () => import("Routes/dashboard/ecommerce"),
	loading: () => <RctPageLoader />,
});

//ManageEquipment dashboard
const AsyncManageEquipmentDashboard = Loadable({
    loader: () => import("Routes/dashboard/manageEquipment"),
    loading: () => <RctPageLoader />,
}); 

//Gtp dashboard 
const AsyncGtpDashboard = Loadable({
    loader: () => import("Routes/dashboard/gtp"),
    loading: () => <RctPageLoader />,
}); 

// agency dashboard
//const AsyncSaasDashboardComponent = Loadable({
	//loader: () => import("Routes/dashboard/saas"),
	//loading: () => <RctPageLoader />,
//});

// agency dashboard
const AsyncAgencyDashboardComponent = Loadable({
	loader: () => import("Routes/dashboard/agency"),
	loading: () => <RctPageLoader />,
});

// boxed dashboard
const AsyncNewsDashboardComponent = Loadable({
	loader: () => import("Routes/dashboard/news"),
	loading: () => <RctPageLoader />,
});

//sorter details
const AsyncSorterDetailsComponent = Loadable({
	loader: () => import("Routes/dashboard/sorter_details"),
	loading: () => <RctPageLoader />,
});

//Chute status table
const AsyncChuteStatusComponent = Loadable({
	loader: () => import("Routes/dashboard/chuteStatus"),
	loading: () => <RctPageLoader />,
});

//Induction status table
const AsyncInductStatusComponent = Loadable({
	loader: () => import("Routes/dashboard/inductStatus"),
	loading: () => <RctPageLoader />,
});

//Zonal And Station Details table
const AsyncGtpZnlStnDtls = Loadable({
	loader: () => import("Routes/dashboard/gtp/znlstnDtls"),
	loading: () => <RctPageLoader />,
});

export {
	AsyncSorterDetailsComponent,
	AsyncChuteStatusComponent,
	AsyncManageEquipmentDashboard,
	AsyncInductStatusComponent,
	AsyncGtpDashboard,
	AsyncGtpZnlStnDtls
	
};
