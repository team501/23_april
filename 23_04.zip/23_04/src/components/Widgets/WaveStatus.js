/**
 * InductsForTheDay
 */
import React, { Component } from 'react';

import { connect } from 'react-redux';  // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component 

//json
import json from 'JsnCnfg/MngEqpmnt/UntSrtrMnDshbrd/waveStatusTodayJson.json';

// intl messages
import IntlMessages from 'Util/IntlMessages';

// api
import api from 'Api';
import CountUp from 'react-countup';
//chart
import TinyAreaChart from 'Components/Charts/TinyAreaChart';
//chart config
import ChartConfig from 'Constants/chart-config';
//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';
import Grid from '@material-ui/core/Grid';

// helpers
import { hexToRgbA } from 'Helpers/helpers';
import {graphQlURLPrd} from '../../services/Config.js';
import CircularProgressbar from 'react-circular-progressbar';
import { ProgressBar, Label } from 'react-bootstrap';
import NumberClass, {NumberFormatter} from 'Util/NumberClass';

import Spinner from 'Util/Spinner';

class WaveStatus extends Component {

	constructor(props) {
		super(props);
		this.state = { 
						allocated: 0,
						sorted: 0,
						remaining: 0,
						waves: 0,
						units: 0,
						allocatedPercentage: 0,
						sortedPercentage: 0,
						remainingPercentage: 0,
					    isLoading:true
					 };
	}

	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getRecentOrders();
	}

	//Comparing props and triggering refresh
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.getRecentOrders();
		}
	}

	// recent orders
	getRecentOrders() {
		let query = json.container.leftSegment.components[0].options.query;
				
		fetch(graphQlURLPrd, {
			method: 'POST',
			headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json',
			},
			body: JSON.stringify({
				query
			})
		})
		.then(r => r.json())
		.then(data => { 
			//console.log("00000000000000000000000000000000000000000000000");
			console.log(data.data.getWaveStatusData[0]);
			//console.log("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
		    this.setState({ 
					    	allocated: data.data.getWaveStatusData.allocated,
							sorted: data.data.getWaveStatusData.sorted,
							remaining: data.data.getWaveStatusData.remaining,
							waves: data.data.getWaveStatusData.waves,
							units: data.data.getWaveStatusData.units,
							allocatedPercentage: data.data.getWaveStatusData.allocatedPercentage,
							sortedPercentage: data.data.getWaveStatusData.sortedPercentage,
							remainingPercentage: data.data.getWaveStatusData.remainingPercentage,
						    isLoading:false
						  }); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ 
					    	allocated: 0,
							sorted: 0,
							remaining: 0,
							waves: 0,
							units: 0,
							allocatedPercentage: 0,
							sortedPercentage: 0,
							remainingPercentage: 0,
						    isLoading:false
						  }); 
		});
	}

	render() {
			
		//For ProgressBar
		let danger = json.container.leftSegment.components[0].options.danger
		let warning = json.container.leftSegment.components[0].options.warning
		let success = json.container.leftSegment.components[0].options.success
		
		//For labels of progressbar
		let allocated = json.container.leftSegment.components[0].labels.allocated
		let sorted = json.container.leftSegment.components[0].labels.sorted
		let remaining = json.container.leftSegment.components[0].labels.remaining
		
		const { isColorBlind } = this.props;
		
		//Check For color blind and change the color
		if(isColorBlind){
			danger = "#87871f"
			success = "#828275"	
			warning = "#f8e71c"			
		}
		
		if(this.state.isLoading){
			return (<RctCollapsibleCard	colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
										heading={<IntlMessages id="unitsorterDashbrd.waveStatsTody" />}
										fullBlock > 
						<Spinner />
					</RctCollapsibleCard>);
		} else {
			return (
					
							<RctCollapsibleCard
								colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full waveStatus"
								heading={<IntlMessages id="unitsorterDashbrd.waveStatsTody" />}
								fullBlock
							>
							<div className="wave-right"><strong>{<IntlMessages id="unitsorterDashbrd.waves" />} {NumberFormatter(this.state.waves)} {<IntlMessages id="unitsorterDashbrd.units" />} {NumberFormatter(this.state.units)}</strong></div>
							<div className="progressbar-gap">
				                    <ProgressBar>
				                  		<ProgressBar style={{backgroundColor: success}} now={this.state.allocatedPercentage} key={1} />
				                  		<ProgressBar  style={{backgroundColor: warning}} now={this.state.sortedPercentage} key={2} />
				                  		<ProgressBar style={{backgroundColor: danger}} now={this.state.remainingPercentage} key={3} />
				                  	</ProgressBar>
									</div>
				                  		<Grid container>
			                  		<Grid style={{textAlign: 'center'}}container>
										<Grid item xs={4} sm={4}>
											<Label style={{backgroundColor: success,color:'white', padding:'5px'}} >{<IntlMessages id="unitsorterDashbrd.waveStatus.allocated" />}</Label>{' '}
											<Grid item xs={12} sm={12} style={{fontSize: 'x-large'}}>
												(<NumberClass  number={this.state.allocated} />)
											</Grid>
										</Grid>
										<Grid item xs={4} sm={4}>
											<Label style={{backgroundColor: warning,color:'white', padding:'5px'}}>{<IntlMessages id="unitsorterDashbrd.waveStatus.sorted" />}</Label>{' '}
											<Grid item xs={12} sm={12} style={{fontSize: 'x-large'}}>
												(<NumberClass  number={this.state.sorted} />)
											</Grid>
										</Grid>
										<Grid item xs={4} sm={4}>
											<Label style={{backgroundColor: danger,color:'white', padding:'5px'}}>{<IntlMessages id="unitsorterDashbrd.waveStatus.remaining" />}</Label>
											<Grid item xs={12} sm={12} style={{fontSize: 'x-large'}}>
												(<NumberClass  number={this.state.remaining} />)
											</Grid>
										</Grid>
									</Grid>
									</Grid>
			            </RctCollapsibleCard>
						
					);
		}
		
	}
}


// map state to props
// Here we can fetch the value of isColorBlind as props
const mapStateToProps = ({ settings }) => {
	const { isColorBlind ,locale} = settings;
	console.log("isColorBlind value inside mapstateToProps -- "+ isColorBlind);
	return { isColorBlind,locale };
};


export default withRouter(connect(mapStateToProps)(WaveStatus));