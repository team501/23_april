import React, { Component } from 'react';

// intl messages
import IntlMessages from 'Util/IntlMessages';
import NumberClass from 'Util/NumberClass';



// Import custom examples
import SegmentedArcProgressbar from './arc/SegmentedArcProgressbar';

class OverallWorkMonitor extends Component {
    render(){
	const percentage = 35;
      return(
        <div className="app-horizontal collapsed-sidebar">
        <div className="app-container">
            <div className="rct-page-wrapper">
                <div className="rct-app-content">
                    <div className="app-header">
                      <div className="componentbg overall-work-monitor row-no-margin">
                       <div className="title overall-gap"><IntlMessages id="GTP.overallWork" /></div>
											 	<div className="col-sm-5 col-md-5 col-lg-5 col-xl-5 text-center leftAlign">
													<div className="subtitle"><b><IntlMessages id="GTP.overallWork.Productivity" /></b></div>
														<div className="overAllG">
														<div className="ArcGauge" style={{ width: '120px', height: '120px' , paddingLeft: '5px'}}>
															<SegmentedArcProgressbar percentage={percentage}  segments={20} textColor={"#000000"}/>
														</div>
														</div>
														<div className="titleBar"><IntlMessages id="GTP.overallWork.TotalAverage" /></div>
														<div className="station-status-activetext"><i><IntlMessages id="GTP.overallWork.LastHour" /></i></div>
												</div>
												<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center leftAlign">
												<div className="subtitle"><b><IntlMessages id="GTP.overallWork.StationStatus" /></b></div>
													<div>
														<div className="station-status-textblack"><b><NumberClass  number={99} /></b></div> 
														<div className="station-status-activetext"><IntlMessages id="GTP.overallWork.Total" /></div>
													</div>
												<div>
														<div className="station-status-textblack"><b><NumberClass  number={88} /></b></div> 
														<div className="station-status-activetext"><IntlMessages id="GTP.overallWork.Active" /></div>
													</div>
												<div>
														<div className="station-status-textblack"><NumberClass  number={12} /></div> 
														<div className="station-status-activetext"><IntlMessages id="GTP.overallWork.Inactive" /></div>
													</div>
												</div>
												<div className="col-sm-3 col-md-3 col-lg-3 col-xl-3 text-center leftAlign">
												<div className="subtitle"><b><IntlMessages id="GTP.overallWork.BinStatus" /></b></div>
												<div>
														<div className="station-status-textblack"><NumberClass  number={9999} /></div> 
														<div className="station-status-activetext"><IntlMessages id="GTP.overallWork.Processed" /></div>
													</div>
												<div>
														<div className="station-status-textblack"><NumberClass  number={999} /></div> 
														<div className="station-status-activetext"><i><IntlMessages id="GTP.overallWork.LastHour" /></i></div>
														<div className="station-status-activetext"><IntlMessages id="GTP.overallWork.ProcessRate" /></div>
													</div>
												</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                      
      );
    }
  }
export default OverallWorkMonitor;
