import React, { Component } from 'react';

import {Link} from 'react-router-dom';

import Pbar from './Pbar.js';

import 'react-circular-progressbar/dist/styles.css';

// intl messages
import IntlMessages from 'Util/IntlMessages';
import NumberClass from 'Util/NumberClass';

import Paper from '@material-ui/core/Paper';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
// Import custom examples
import SegmentedArcProgressbar from '../arc/SegmentedArcProgressbar';

class OverallWorkMonitor extends Component {
state = {
        ordersStatus: null,
        zone: "all"
    }
    
    componentDidMount() {
        this.getOrdersStatus();
    }
    
    // get orders status
    getOrdersStatus() {
        this.setState(
            { ordersStatus: [
                    {
                        "id": 1,
                        "label": "Picking",
                        "meassure":{
                            "progress":"In Units",
                            "time":"hh:mm:ss"
                        },
                        "total": {
                            "units": 26000,
                            "time": "99:99:99"
                        },
                        "productivity": {
                            "percent": 35,
                            "units": "9999"
                        },
                        "binRate": {
                            "process": 9999,
                            "processRate": 999
                        },
                        "others": {
                            "activeStations": 999,
                            "dwellTime":"00:00:00"
                        }
                    },
                    {
                        "id": 2,
                        "label": "Consolidation",
                        "meassure":{
                            "progress":"In Tasks",
                            "time":"hh:mm:ss"
                        },
                        "total": {
                            "units": 26000,
                            "time": "99:99:99"
                        },
                        "productivity": {
                            "percent": 55,
                            "units": 9999
                        },
                        "binRate": {
                            "process": 9999,
                            "processRate": 999
                        },
                        "others": {
                            "activeStations": 999,
                            "dwellTime":"00:00:00"
                        }
                    },
                    {
                        "id": 3,
                        "label": "Decanting",
                        "meassure":{
                            "progress":"In Tasks",
                            "time":"hh:mm:ss"
                        },
                        "total": {
                            "units": 26000,
                            "time": "99:99:99"
                        },
                        "productivity": {
                            "percent": 75,
                            "units": 9999
                        },
                        "binRate": {
                            "process": 9999,
                            "processRate": 999
                        },
                        "others": {
                            "activeStations": 999,
                            "dwellTime":"00:00:00"
                        }
                    },
                    {
                        "id": 4,
                        "label": "Cycle Count",
                        "meassure":{
                            "progress":"In Tasks",
                            "time":"hh:mm:ss"
                        },
                        "total": {
                            "units": 26000,
                            "time": "99:99:99"
                        },
                        "productivity": {
                            "percent": 45,
                            "units": 9999
                        },
                        "binRate": {
                            "process": 9999,
                            "processRate": 999
                        },
                        "others": {
                            "activeStations": 999,
                            "dwellTime":"00:00:00"
                        }
                    }
                ] 
            }
        );
	}
	
    render(){
		const { ordersStatus } = this.state;

		const percentage = 35;

      return(
        <div className="app-horizontal collapsed-sidebar">
        <div className="app-container">
            <div className="rct-page-wrapper">
                <div className="rct-app-content">
                    <div className="app-header">
                      	<div className="operation_bg overall-work-monitor">
							<div class="row row-no-margin">
								<div className="col-sm-10 col-md-10 col-lg-10 col-xl-10 title"><IntlMessages id={'GTP.overallWork.Operations'} /></div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 text-right">
									<FormControl fullWidth>
										<Select
										value={this.state.zone}
										onChange={this.handleChange}
										name="zone"
										IconComponent={props => (
											<i {...props} className={`material-icons ${props.className}`}>
												keyboard_arrow_down
											</i>
										)}
										>
										<MenuItem value="all"><IntlMessages id={'GTP.overallWork.ALL ZONES'} /></MenuItem>
										<MenuItem value={10}><IntlMessages id={'GTP.overallWork.ZONE A'} /></MenuItem>
										<MenuItem value={20}><IntlMessages id={'GTP.overallWork.ZONE B'} /></MenuItem>
										<MenuItem value={30}><IntlMessages id={'GTP.overallWork.ZONE C'} /></MenuItem>

										{/* <MenuItem value="all">ALL ZONES</MenuItem>
										<MenuItem value={10}>ZONE A</MenuItem>
										<MenuItem value={20}>ZONE B</MenuItem>
										<MenuItem value={30}>ZONE C</MenuItem> */}
										</Select>
									</FormControl>
								</div>
							</div>
							<div class="row row-no-margin text-center p-10">
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1"></div>
								<div className="col-sm-5 col-md-5 col-lg-5 col-xl-5"></div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 opHeadertext"> <IntlMessages id={'GTP.overallWork.operation.Total'} /> </div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 opHeadertext"> <IntlMessages id={'GTP.overallWork.operation.Productivity'} /> </div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 text-nowrap opHeadertext binstatus-text"> <IntlMessages id={'GTP.overallWork.operation.Bin Status'} /> </div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 opHeadertext other-text"> <IntlMessages id={'GTP.overallWork.operation.Others'} /> </div>
							</div>
							{ordersStatus && ordersStatus.map((order, key) => (
							<Link style={{display: 'block' }} to={{ pathname: `/app/dashboard/gtp/${order.label}/znlstnDtls`}}>
							<div className="row row-no-margin opration-radius text-center">
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign station-status-textblack text-middle text-left"> 
									<IntlMessages id={`GTP.overallWork.operation.${order.label}`} />
								</div>
								<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign"> 
									<div className="row row-no-margin">
										<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 text-right">
											<div className="opcontainersubtext"><IntlMessages id={'GTP.overallWork.operation.Progress'} /></div>
												<div className="opsmalltext"><i>(<IntlMessages id={`GTP.overallWork.operation.${order.meassure.progress}`} />)</i></div>
											<div className="opcontainersubtext"><IntlMessages id={'GTP.overallWork.operation.Time'} /></div>
											<div className="opsmalltext"><i>{`(${order.meassure.time})`}</i></div>
										</div>
									<div className="col-sm-7 col-md-7 col-lg-7 col-xl-7 leftAlign"> <Pbar/></div>
								
									</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign"> 
									<div className="station-status-textblack margin17"><NumberClass  number={order.total.units} /></div>
									<div className="station-status-textblack margin28">{order.total.time}</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2"> 
									<div className="opAllG">
										<div className="ArcGauge" style={{ width: '80px', height: '80px'}}>
											<SegmentedArcProgressbar percentage={order.productivity.percent}  segments={20} textColor={"#000000"}/>
											<div className="prodLabel"><b><NumberClass  number={order.productivity.units} /></b>/<NumberClass  number={9999} /></div>
											<div className="opsmalltext"><i>(<IntlMessages id={'GTP.overallWork.operation.Last Hour'} />)</i></div>
										</div>		
									</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 alignBinStatus "> 
									<div className="station-status-textblack margin17"><NumberClass  number={order.binRate.process} /></div>
									<div className="opsmalltext station-status-activetext"><IntlMessages id={'GTP.overallWork.operation.Processed'} /></div>
									<div className="station-status-textblack margin10"><NumberClass  number={order.binRate.processRate} /></div>
									<div className="opsmalltext"><i><IntlMessages id={'GTP.overallWork.operation.Last Hour'} /></i></div>
									<div className="opsmalltext station-status-activetext noWrap"><IntlMessages id={'GTP.overallWork.operation.Process Rate'} /></div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 alignOthers">
									<div className="station-status-textblack margin17"><NumberClass  number={order.others.activeStations} /></div>
									<div className="opsmalltext station-status-activetext noWrap"><IntlMessages id={'GTP.overallWork.operation.Active Stations'} /></div>
									<div className="station-status-textblack opblack">&#x2BC6;{order.others.dwellTime}</div>
									{/* <div className="opsmalltext"><i><IntlMessages id={'GTP.overallWork.operation.Last Hour'} /></i></div> */}
									<div className="opsmalltext station-status-activetext noWrap"><IntlMessages id={'GTP.overallWork.operation.Dwell Time'} /></div>
								</div>								
							</div>
							</Link>
							))}
							<div className="clearboth"></div>
							<Paper key={"completed"} elevation={2} square={true} component={'div'} className="mb-10 m-10 size-10 comp-blue"></Paper>
							<span className="paperLabel"><IntlMessages id={'GTP.overallWork.operation.Completed'} /></span>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<Paper key={"lagging"} elevation={2} square={true} className="size-10 bg-danger"></Paper>
							<Paper key={"leading"} elevation={2} square={true} className="mb-10 m-10 size-10 bg-success"></Paper>
							<span className="paperLabel"><IntlMessages id={'GTP.overallWork.operation.Time lapse'} /></span>
                     	</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                      
      );
    }
  }
export default OverallWorkMonitor;
